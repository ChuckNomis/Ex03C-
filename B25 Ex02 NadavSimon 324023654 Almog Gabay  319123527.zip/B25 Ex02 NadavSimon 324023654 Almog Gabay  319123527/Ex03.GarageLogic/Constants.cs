﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarageLogic
{
    public class Constants
    {
        public       const int k_numberOfWheelsCar = 4;
        public       const int k_numberOfWheelsMotorcycle = 2; 
        public       const int k_numberOfWheelsTruck = 12; 
    }
}
